import React from 'react';

const Contact=()=>{
    return(
    <div id="contact">
        <div>
    <h1 id="Contact_heading">Contact Us</h1>
    </div>
    <br/>
<div id="contact_box">

		<fieldset>
			<form>
			<div class="form-group">
				<label for="name">Name:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Name"/>
			</div>
			<div class="form-group">
				<label for="email">Email:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Email"/>
			</div>
			<div class="form-group">
				<label for="phone">Phone:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Phone"/>
			</div>
			<div class="form-group">
				<label for="message">Message:</label>
				<textarea name="message" id="message" cols="20" rows="10"></textarea>
			</div>
		</form>
        <div id="button_box">
        <button  id="button" type="submit">SUBMIT</button>
        </div>
		</fieldset>
	</div>
</div>    
    )
}
export default Contact;