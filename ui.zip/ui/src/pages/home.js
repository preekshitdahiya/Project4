import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
const Home=()=> {
   return(<>
     <div>  
<section>
	<h1 id="tutorialheading">Tutorials</h1>
<section id="Tutorials">
	<div class="box">
	<img src="./images/os.jpg" alt="OperatingSystem"/>     
	<h2>OPERATING SYSTEM</h2>
	</div>
	<div class="box">
	<img src="./images/opps.jpg" alt="ObjectOrientedProgramming"/>     
	<h2>OBJECT ORIENTED PROGRAMMING</h2>
	</div>
	<div class="box">
	<img src="./images/dsa.jpg" alt="DataStructure"/>     
	<h2>DATA STRUCTURE</h2>
	</div>
</section>

<nav id="tutorialnav">
	<NavLink to="/tutorials"><button><h3>see all</h3></button></NavLink>
	</nav>
</section>

<section>
	<h1 id="eventsheading">Events</h1>
	<section id="Events">
	<div class="box">
	<img src="./images/codelikeninja.jpg" alt="CodeLikeNinja"/>     
	<h2>CODE LIKE NINJA</h2>
	</div>
	<div class="box">
	<img src="./images/experttalk.jpg" alt="ExpertTalk"/>     
	<h2>EXPERT TALK</h2>
	</div>
	<div class="box">
	<img src="./images/ideathon.jpg" alt="Ideathon"/>     
	<h2>IDEATHON</h2>
	</div>
    </section>
<nav id="eventsnav">
		<NavLink to="/events"><button><h3>see all</h3></button></NavLink>
	</nav>
</section>

<section id="contact">
	<h1>CONTACT US</h1>
	<div id="contact_box">
		<fieldset>
			<form>
			<div class="form-group">
				<label for="name">Name:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Name"/>
			</div>
			<div class="form-group">
				<label for="email">Email:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Email"/>
			</div>
			<div class="form-group">
				<label for="phone">Phone:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Phone"/>
			</div>
			<div class="form-group">
				<label for="message">Message:</label>
				<textarea name="message" id="message" cols="20" rows="5"></textarea>
			</div>
		</form>
		</fieldset>
	</div>
</section>
     </div>
	 <Outlet/>
	 </>
    );
}

export default Home;