import React from 'react';

const Join=()=>{
    return(
    <div id="join">
        <div>
    <h1 id="join_heading">JOIN US</h1>
    </div>
    <br/>
<div id="join_box">

		<fieldset>
			<form>
			<div class="form-group">
				<label for="name">Name:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Name"/>
			</div>
			<div class="form-group">
				<label for="email">Email:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Email"/>
			</div>
			<div class="form-group">
				<label for="phone">Phone:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Phone"/>
			</div>
            <div class="form-group">
				<label for="Education">Education:</label>
				<input type="text" name="name" id="name" placeholder="Enter your Education qualifications"/>
			</div>
			<div class="form-group">
				<label for="message">Reason:</label>
				<textarea name="message" id="message" placeholder="Enter why you want to join us?" cols="20" rows="10"></textarea>
			</div>
		</form>
        <div id="button_box">
        <button  id="button" type="submit">SUBMIT</button>
        </div>
		</fieldset>
	</div>
</div>    
    )
}
export default Join;