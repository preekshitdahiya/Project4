import React from 'react';
import Join from './join_us';
import {Outlet,NavLink} from 'react-router-dom';
const Navbar=()=> {
    return(
        <>
          <nav id="navbar">
            <div id="logo">
                <img src="./images/logo.png" alt="ExamPreparations.com"/>
            </div>
            <ul>
                 <li class="item"><NavLink to="/">Home</NavLink></li>
                 <li class="item"><NavLink to="/tutorials">Tutorials</NavLink></li>
                 <li class="item"><NavLink to="/events">Events</NavLink></li>
                 <li class="item"><NavLink to="/contact">Contact us</NavLink></li>
                 <li class="item"><NavLink to="/about">About us</NavLink></li>

            </ul>
        
        </nav>
      
        <section id="Home">
            <h1>ExamPreparations</h1>
            <p>WELCOME TO EXAM PREPATIONS</p>
            <NavLink to="/join"><button>JOIN US</button></NavLink>
        </section>
        <Outlet/>
        </>
        )
}
export default Navbar;