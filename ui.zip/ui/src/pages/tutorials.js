import React from 'react';
 const Tutorials=()=>{
    return(
<div>  
  
    <h1 id="tutorials_heading">Tutorials</h1>
  
        <section id="tutorials">
         <div class="box">
         <img src="./images/os.jpg" alt="OperatingSystem"/>     
         <h2>OPERATING SYSTEM</h2>
         </div>

         <div class="box">
         <img src="./images/opps.jpg" alt="ObjectOrientedProgramming"/>     
         <h2>OBJECT ORIENTED PROGRAMMING</h2>
         </div>

         <div class="box">
         <img src="./images/dsa.jpg" alt="DataStructure"/>     
         <h2>DATA STRUCTURE</h2>
         </div>
    </section>
    <section id="tutorials">
         <div class="box">
         <img src="./images/ai.jpg" alt="ArtificialIntelligence"/>     
         <h2>ARTIFICIAL INTELLIGENCE</h2>
         </div>

         <div class="box">
         <img src="./images/coa.jpg" alt="ComputerOrganizationAndArchitecture"/>     
         <h2>COMPUTER ARCHITECTURE</h2>
         </div>

         <div class="box">
         <img src="./images/daa.jpg" alt="DesignAndAnalysisOfAlgorithms"/>     
         <h2>DESIGN and ANALYSIS OF ALGORITHMS</h2>
         </div>
    </section>
    <section id="tutorials">
         <div class="box">
         <img src="./images/evs.jpg" alt="EnvironmentalStudies"/>     
         <h2>ENVIRONMENTAL STUDIES</h2>
         </div>

         <div class="box">
         <img src="./images/cyber security.jpg" alt="CyberSecurity"/>     
         <h2>CYBER SECURITY</h2>
         </div>

         <div class="box">
         <img src="./images/html.jpg" alt="WebTechnologies"/>     
         <h2>WEB TECHNOLOGIES</h2>
         </div>
    </section>
    <section id="tutorials">
         <div class="box">
         <img src="./images/java.jpg" alt="Java"/>     
         <h2>JAVA</h2>
         </div>

         <div class="box">
         <img src="./images/pps.jpg" alt="ProgrammingForProblemSolving"/>     
         <h2>PPS</h2>
         </div>

         <div class="box">
         <img src="./images/uhv.jpg" alt="UniversalHumanValues"/>     
         <h2>UNIVERSAL HUMAN VALUES</h2>
         </div>
    </section>
    <section id="tutorials">
         <div class="box">
         <img src="./images/cn.jpg" alt="ComputerNetworks"/>     
         <h2>COMPUTER NETWORKS</h2>
         </div>

         <div class="box">
         <img src="./images/dbms.jpg" alt="DatabaseManagementSystem"/>     
         <h2>DATABASE MANAGEMENT SYSTEM</h2>
         </div>

         <div class="box">
         <img src="./images/se.jpg" alt="SoftwareEngineering"/>     
         <h2>SOFTWARE ENGINEERING</h2>
         </div>
    </section>

</div>
    );
 }
 export default Tutorials;