import React from 'react';
 const Events=()=>{
    return(
    <div>
    <h1 id="events_heading">Events</h1>
	
         <section id="Events">
	     <div class="box">
	     <img src="./images/codelikeninja.jpg" alt="CodeLikeNinja"/>     
	     <h2>CODE LIKE NINJA</h2>
	     </div>
	     <div class="box">
	     <img src="./images/experttalk.jpg" alt="ExpertTalk"/>     
	     <h2>EXPERT TALK</h2>
	     </div>
	     <div class="box">
	     <img src="./images/ideathon.jpg" alt="Ideathon"/>     
         <h2>IDEATHON</h2>
	     </div>
         </section>

         <section id="Events">
	     <div class="box">
	     <img src="./images/hackathon.jpg" alt="Hackathon"/>     
	     <h2>HACKATHON</h2>
	     </div>
	     <div class="box">
	     <img src="./images/webinar.jpg" alt="Webinar"/>     
	     <h2>WEBINAR</h2>
	     </div>
	     <div class="box">
	     <img src="./images/workshop.jpg" alt="Workshops"/>     
         <h2>WORKSHOPS</h2>
	     </div>
         </section>

    </div>
    )
}
export default Events;
