import React from 'react';
import { Outlet,NavLink } from 'react-router-dom';
const Footer=()=> {
    return(
        
<footer>
	<div id="row">
	  <div class="col">
		<img src="project/logo.png" alt="ExamPreparation.com" id="logo"/>
        <h2>ExamPreparations.com</h2>
		<p>Contact For More Details and Feedback<br/>
		 Copyright &copy;My ExamPreparations.com.<br/>
		All rights reserved!</p>
	  </div>
	  <div class="col">
	  	<h2>Address:</h2>
	  	<p>CGC College of Engineering<br/>
           Landran,Mohali<br/>
           Punjab,140307<br/>
           India
	  	</p>
	  	<p id="email">preekshitdahiyasaini@gmail.com</p>
	  	<h3>+91-8218882128</h3>
	  </div>
	  <div class="col">
	  	<h2>Links:</h2>
	  	<ul>
		         <li class="links"><NavLink to="/">Home</NavLink></li>
                 <li class="links"><NavLink to="/tutorials">Tutorials</NavLink></li>
                 <li class="links"><NavLink to="/events">Events</NavLink></li>
                 <li class="links"><NavLink to="/contact">Contact us</NavLink></li>
                 <li class="links"><NavLink to="/about">About us</NavLink></li>
	  	</ul>
	  </div>
	  <div class="col">
	  	<h2>Newsletter:</h2>
	  	<form id="footer_form">
	  		<img id="envelope" src="./images/envelope.png"/>
	  		<input type="email" placeholder="Enter your email-id"/>
	  		<button type="submit"><img id="arrow" src="./images/arrow.jpg"/></button>
	  	</form>
             
	  </div>
    </div>
	<Outlet/>
</footer>

    );

}
export default Footer;