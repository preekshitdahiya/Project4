import React from 'react';
import Home from './pages/home';
import Navbar from './pages/navbar';
import Join from './pages/join_us';
import Tutorials from './pages/tutorials';
import Events from './pages/events';
import About from './pages/about_us';
import Contact from './pages/contact_us';
import Footer from './pages/footer';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
function App() {
  
   return (
   <> 
   
   
        <Router>
        <Navbar/>
         <Routes>
            <Route path="/" element={<Home/>}/>
                        
            <Route path="/tutorials" element={<Tutorials/>}/>
            
            <Route path="/events" element={<Events/>}/>
            
            <Route path="/contact" element={<Contact/>}/>
             
            <Route path="/about" element={<About/>}/>

             <Route path="/join" element={<Join/>}/> 
            </Routes>
            <Footer/>
        </Router>
  
   
   
  
   </>
   )
}
export default App;

